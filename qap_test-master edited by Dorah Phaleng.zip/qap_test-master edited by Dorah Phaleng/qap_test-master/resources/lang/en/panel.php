<?php

return [
    'site_title' => 'test-mvn',
];

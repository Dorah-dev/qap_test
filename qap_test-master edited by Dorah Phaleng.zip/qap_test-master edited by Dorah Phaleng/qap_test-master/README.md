## QuickAdminPanel testing

Just a small project for testing and playing with QAP projects
